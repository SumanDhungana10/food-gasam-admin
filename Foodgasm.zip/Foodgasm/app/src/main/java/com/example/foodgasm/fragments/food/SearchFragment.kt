package com.example.foodgasm.fragments.food

import androidx.fragment.app.Fragment
import com.example.foodgasm.R

class SearchFragment:Fragment(R.layout.fragment_search) {
}