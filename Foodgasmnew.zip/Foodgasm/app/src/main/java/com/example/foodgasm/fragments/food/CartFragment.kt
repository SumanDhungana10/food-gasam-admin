package com.example.foodgasm.fragments.food

import androidx.fragment.app.Fragment
import com.example.foodgasm.R

class CartFragment:Fragment(R.layout.fragment_cart) {
}