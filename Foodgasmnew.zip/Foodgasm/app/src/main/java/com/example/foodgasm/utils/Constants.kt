package com.example.foodgasm.utils

object Constants {
    const val USER_COLLECTION="user"
}