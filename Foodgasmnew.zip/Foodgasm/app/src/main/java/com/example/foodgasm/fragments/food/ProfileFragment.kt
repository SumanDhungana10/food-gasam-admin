package com.example.foodgasm.fragments.food

import androidx.fragment.app.Fragment
import com.example.foodgasm.R

class ProfileFragment:Fragment(R.layout.fragment_profile) {
}